/*
This comment reside in src/coffee/main.coffee
*/


(function() {
  if (typeof console !== "undefined" && console !== null) {
    console.log('Hello world from the coffeescript file!');
  }

}).call(this);
